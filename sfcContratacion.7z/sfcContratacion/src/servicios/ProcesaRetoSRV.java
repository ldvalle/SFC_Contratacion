package servicios;

import entidades.interfaceDTO;
import entidades.retoOT_DTO;
import entidades.periodosDTO;

import java.util.Collection;
import dao.RetornosDAO;


public class ProcesaRetoSRV {

	public Boolean LeeSolicitudes() {
		RetornosDAO miDao = new RetornosDAO();
		
		Collection<interfaceDTO>lstInterface = miDao.getLstCasos();
		
		for(interfaceDTO fila: lstInterface) {
			
			if(!ProcesaCaso(fila)) {
				System.out.println("Error al procesar Caso");
				return false;
			}
			
		}		

		
		return true;
	}
	
	private Boolean ProcesaCaso(interfaceDTO reg) {
		periodosDTO miPeriodo = null;
		
		RetornosDAO miSrv = new RetornosDAO();
		
		miPeriodo = miSrv.getPeriodoDT();
		
		switch(reg.tipo_sol.trim()) {
			case "INCORPORACION":
			case "MANSER":
			case "RETCLI":
				retoOT_DTO regSts = null;
				
				//Recupero Status Actual
				regSts=miSrv.getStsOT(reg.caso, reg.nro_orden);
				
				//Recupero Ubicaciones
				
				//Recupero Observaciones
				
				//Informo Resultado
				if(regSts.ident_etapa=="FI") {
					regSts.iSts=10;
					regSts.DescriSts="Finalizada";
				}else {
					switch(regSts.status) {
						case "NOTI":
						case "NORE":
						case "ASOL":
						case "CTEC":
						case "RAUV":
						case "PLAN":
						case "CERR":
						case "NOTP":
							regSts.iSts=5;
							regSts.DescriSts="En Proceso";

							break;
						case "REAL":
							regSts.iSts=10;
							regSts.DescriSts="Finalizada";

							break;
					}
					
				}
				
				if(! miSrv.setStatus(regSts, reg.caso, reg.nro_orden)) {
					System.out.println("Fallo actualizar Sts. para Caso " + reg.caso + " Nro.Orden " + reg.nro_orden);
					return false;
				}
				
				break;
			
			case "CONTACTO":
				
				break;
		}		
		
		return true;
	}
}
