package entidades;


public class ordenDTO {
	public String		tipo_orden;
	public String		numero_orden;
	public long			mensaje_xnear;
	public int			servidor;
	public String		sucursal;
	public String		area_emisora;
	public String		fecha_inicio; //year to second
	public String		ident_etapa;
	public String		term_dir;
	public String		area_ejecutora;
	public String		duracion; // year to second
	public String		prioridad;
	public String		estado;
	public String		rol_usuario;
	public String		tema;
	public String		trabajo;
	public String		clase;
	public String		tipo_orden_rel;
	public long			numero_orden_rel;
	public long			valor_cobro;
	public long			numero_cliente;
	public String		vencimiento; //Date
	public String		cuenta_conver;
	public String		sucu_usu;	
	
}
