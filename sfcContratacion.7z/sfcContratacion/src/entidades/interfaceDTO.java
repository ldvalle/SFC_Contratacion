package entidades;

public class interfaceDTO {

	public long		caso;
	public long		nro_orden;
	public String	tarifa;
	public String	tipo_sol;
	public String	data_in;
	public int		estado;
	public String	procedimiento;
	
}
