package entidades;

public class retoOT_DTO {
	public String	tipo_orden;
	public String	numero_orden;
	public long		mensaje_xnear;
	public String	ident_etapa;
	public String	status;
	public String	fecha_proc;  //Year to second
	public int		iSts;
	public String	DescriSts;

}
