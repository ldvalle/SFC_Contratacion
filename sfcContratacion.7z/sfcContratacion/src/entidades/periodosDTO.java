package entidades;

import java.util.Date;

public class periodosDTO {
	public Date dFechaDesde;
	public Date dFechaHasta;
	public String dtFechaDesde;
	public String dtFechaHasta;
	
}
