package entidades;

public class ClienteDTO {

	public long	NroCliente;
	public String sDV;
	public String sSucursal;
	
}
