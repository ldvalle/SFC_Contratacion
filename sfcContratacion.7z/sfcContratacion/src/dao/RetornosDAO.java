package dao;

import conectBD.UConnection;
import entidades.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.Collection;
import java.util.Vector;

public class RetornosDAO {

	public Collection<interfaceDTO> getLstCasos(){
		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;
		
		Vector<interfaceDTO> miLista = new Vector<interfaceDTO>();
		
		String sql = query1();

		try{
			con = UConnection.getConnection();
			pstm = con.prepareStatement(sql);


			rs = pstm.executeQuery();
			
			while(rs.next()){
				interfaceDTO miReg = new interfaceDTO();
				
				miReg.caso = rs.getLong("caso");
				miReg.nro_orden = rs.getLong("nro_orden");
				miReg.tipo_sol = rs.getString("tipo_sol");
				
				miLista.add(miReg);
			}
			
		}catch(SQLException ex){
			ex.printStackTrace();
			throw new RuntimeException(ex);
		}finally{
			try{
				if(rs != null) rs.close();
				if(pstm != null) pstm.close();
			}catch(Exception ex){
				ex.printStackTrace();
				throw new RuntimeException(ex);
			}
		}
		
		return miLista;
	}

	public retoOT_DTO getStsOT(long caso, long orden) {
		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		retoOT_DTO miReg = new retoOT_DTO();
		
		String sql = query2();

		try{
			con = UConnection.getConnection();
			pstm = con.prepareStatement(sql);

			pstm.setLong(1, caso);
			pstm.setLong(2, orden);
			
			rs = pstm.executeQuery();
			
			while(rs.next()){
				miReg.tipo_orden = rs.getString("tipo_orden");
				miReg.numero_orden = rs.getString("numero_orden");
				miReg.mensaje_xnear = rs.getLong("mensaje_xnear");
				miReg.ident_etapa = rs.getString("ident_etapa");
				miReg.status = rs.getString("ots_status");
				miReg.fecha_proc = rs.getString("ots_fecha_proc");
			}
			
		}catch(Exception ex){
			System.out.println("getStsOT()");
			ex.printStackTrace();
			throw new RuntimeException(ex);
		}finally{
			try{
				if(rs != null) rs.close();
				if(pstm != null) pstm.close();
			}catch(Exception ex){
				ex.printStackTrace();
				throw new RuntimeException(ex);
			}
		}		
		
		return miReg;
	}

	public Boolean setStatus(retoOT_DTO reg, long Caso, long Orden) {
		Connection con = null;
		PreparedStatement pstm = null;
		
		String sql = query3();
	
		try{
			con = UConnection.getConnection();
			pstm = con.prepareStatement(sql);

			pstm.setInt(1, reg.iSts);
			pstm.setString(2, reg.DescriSts);
			pstm.setString(3, reg.fecha_proc);
			pstm.setLong(4, Caso);
			pstm.setLong(5, Orden);
			
			pstm.executeUpdate();
			
		}catch(Exception ex){
			System.out.println("getStsOT()");
			ex.printStackTrace();
			throw new RuntimeException(ex);
		}finally{
			try{
				if(pstm != null) pstm.close();
			}catch(Exception ex){
				ex.printStackTrace();
				throw new RuntimeException(ex);
			}
		}		
		
		return true;
	}
	
	public periodosDTO getPeriodoDT() {
		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		periodosDTO miReg = new periodosDTO();
		
		String sql = query4("DT");

		try{
			con = UConnection.getConnection();
			pstm = con.prepareStatement(sql);

			rs = pstm.executeQuery();

			if(rs.next()) {
				miReg.dtFechaDesde = rs.getString("fDesde");
				miReg.dtFechaHasta = rs.getString("fhasta");
			}

		}catch(Exception ex){
			System.out.println("getStsOT()");
			ex.printStackTrace();
			throw new RuntimeException(ex);
		}finally{
			try{
				if(rs != null) rs.close();
				if(pstm != null) pstm.close();
			}catch(Exception ex){
				ex.printStackTrace();
				throw new RuntimeException(ex);
			}
		}		
		
		return miReg;
	}
	
	private String query1() {
		String sql;
		
		sql = "SELECT i.caso, i.nro_orden, i.tipo_sol ";
		sql += "FROM sfc_interface i, ";
		sql += "WHERE i.tarifa = 'T1' ";
		sql += "AND i.estado BETWEEN 1 AND 9 ";
		
		return sql;
	}
	
	
	private String query2() {
		String sql;
		
		sql = "SELECT o.tipo_orden, o.numero_orden, o.mensaje_xnear, o.ident_etapa, ";
		sql += "h1.ots_status, h1.ots_fecha_proc ";
		sql += "FROM orden o, ot_hiseven h1 ";
		sql += "WHERE o.sfc_caso = ? ";
		sql += "AND o.sfc_nro_orden = ? ";
		sql += "AND h1.ots_nro_orden = o.numero_orden ";
		sql += "AND h1.ots_fecha_proc = (SELECT MAX(h2.ots_fecha_proc) ";
		sql += "	FROM ot_hiseven h2 ";
		sql += " 	WHERE h2.ots_nro_orden = o.numero_orden) ";
		
		return sql;
	}
	
	private String query3() {
		String sql;
		
		sql = "UPDATE sfc_interface SET ";
		sql += "estado = ?, ";
		sql += "descri_estado = ?, ";
		sql += "fecha_estado = ? ";
		sql += "WHERE caso = ? ";
		sql += "AND orden = ? ";

		return sql;
	}
	
	private String query4(String sTipo) {
		String sql;
		
		if(sTipo.equals("DT")) {
			sql = "SELECT TO_CHAR(TODAY, '%Y-%m-%d') || ' 00:00:00' fdesde, ";
			sql += "TO_CHAR(TODAY, '%Y-%m-%d') || ' 23:59:59' fhasta ";
			sql += "FROM dual ";
		}else {
			sql = "SELECT TODAY fdesde, TODAY fhasta ";
			sql += "FROM dual ";
		}

		return sql;
	}

	private String query5() {
		String sql;
		
		sql = "SELECT fecha, carpeta_destino ";
		sql += "FROM xnear2:historia ";
		sql += "WHERE servidor = 1 ";
		sql += "AND mensaje = ? ";
		sql += "AND fecha BETWEEN ? AND ? ";
		sql += "ORDER BY fecha DESC ";

		return sql;
	}

	private String query6() {
		String sql;
		
		sql = "SELECT texton, pagina ";
		sql += "FROM xnear2:pagina ";
		sql += "WHERE servidor = 1 ";
		sql += "AND mensaje = ? ";
		sql += "ORDER BY pagina ASC ";

		return sql;
	}
	
}
