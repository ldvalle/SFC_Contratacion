package com.edesur;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import entidades.interfaceDTO;
import servicios.ProcesaSolSRV;

public class IniciaSolic {

	public static void main(String[] args) {
		ProcesaSolSRV miSrv = new ProcesaSolSRV();


		if(! miSrv.LeeSolicitudes()) {
			System.out.println("Error al cargar la solicitud.");
			return;
		}
		
/*	
		regIN = CargaIterfaceInicio();
	
		switch(regIN.Procedimiento) {
			case "INCORPORACION":
				System.out.println("Cargando Suministro.");
				if(!CargaSuministro(regIN)) {
					System.out.println("Error al cargar la solicitud.");
					return;
				}
				break;
			case "MANSER":
				
				break;
			case "RETCLI":
				
				break;
		}
*/
		System.out.println("Operaci�n Realizada OK");
	}
/*
	private static dataIncorpoDTO CargaIterfaceInicio() {
		dataIncorpoDTO reg = new dataIncorpoDTO();
		
		
		reg.Caso="10";
		reg.NroOrden="300";
		reg.Nombre="Jorge Saleforce";
		reg.TipoDoc="DNI";
		reg.NroDoc=2145698;
		reg.CodProvincia="C";
		reg.CodPartido="000";
		reg.CodLocalidad="000";
		reg.CodCalle="005003";
		reg.NomCalle="ECHAGUE PEDRO";
		reg.NroDir="1358";
		reg.Piso="12";
		reg.Depto="C";
		reg.codPost=1130;
		reg.TipoIva="COF";
		reg.Ciiu="C3";
		reg.Sucursal="0004";
		reg.TipoReparto="NORMAL";
		reg.Procedimiento = "INCORPORACION";
		
		return reg;
	}
	
	private static Boolean CargaSuministro(dataIncorpoDTO reg) {
		
		ProcesaSolSRV miSrv = new ProcesaSolSRV();
		
		if(!miSrv.CargaSol(reg)) {
			return false;
		}
		
		return true;
	}
*/	
}
