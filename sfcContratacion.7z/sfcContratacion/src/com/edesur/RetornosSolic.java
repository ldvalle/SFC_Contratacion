package com.edesur;

import entidades.interfaceDTO;

public class RetornosSolic {

	public static void main(String[] args) {


	}

}
